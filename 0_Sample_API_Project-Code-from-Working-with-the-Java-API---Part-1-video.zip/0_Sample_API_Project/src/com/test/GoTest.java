package com.test;

import java.io.IOException;
import java.util.Iterator;

import com.uc4.api.Task;
import com.uc4.api.TaskFilter;
import com.uc4.communication.Connection;
import com.uc4.communication.requests.ActivityList;
import com.uc4.communication.requests.CancelTask;
import com.uc4.communication.requests.CreateSession;

public class GoTest {

	public static void main(String[] args) throws IOException{
		
		Connection conn = HandleConnectionToAE();
		
		TaskFilter filter = new TaskFilter();
		ActivityList XMLReq = new ActivityList(filter); //it's an XML request (it inherits from the XMLRequest class
		conn.sendRequestAndWait(XMLReq);
		
		CancelTask myRequest = new CancelTask(1234567,false);
		conn.sendRequestAndWait(myRequest);
		
		if(myRequest.getMessageBox() != null){
			System.out.println("Error: some error happened while retrieving the list of activities.." + myRequest.getMessageBox());
		}else{
			// Successful! we should be able to show the list of activities
			System.out.println("Number of activities returned by AE:" + XMLReq.size());
			
			Iterator<Task> myIterator = XMLReq.iterator();
			
			while(myIterator.hasNext()){
				Task myTask = myIterator.next();
				System.out.println("Record is:" + myTask.getName() + " : " + myTask.getStatusText() + " : " + myTask.getRuntime());
			}
		}
		
	}
	
	
	public static Connection HandleConnectionToAE() throws IOException{
		
		// authentication - part 1: declare AE server
		Connection myAEConnection = Connection.open("192.168.1.60", 2217);
		// authentication - part 2: give credentials
		CreateSession mySession = myAEConnection.login(200,"BSP", "AUTOMIC", "Un1ver$e", 'E');
		
		if(mySession.getMessageBox() != null){
			// there is a message hence there is an error
			System.out.println("--Error: " + mySession.getMessageBox());
			return null;
		}else{
			// connection successful
			System.out.println("+ OK!: Connection Successful!");
			return myAEConnection;
		}
		
	}
	
}
